{
    'name': 'HR Leave Request',
    'version': '1.0',
    'summary': 'Simple leave request module for HR',
    'description': 'This module allows employees to submit leave requests and managers to approve them.',
    'category': 'Human Resources',
    'author': 'Your Name',
    'depends': ['base', 'hr'],
    'data': [
        'security/hr_leave_request_security.xml',
        'security/ir.model.access.csv',
        'views/leave_request_views.xml',
        'views/leave_request_menu.xml',
    ],
    'installable': True,
    'application': True,
}
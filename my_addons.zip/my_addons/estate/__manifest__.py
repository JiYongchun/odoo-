# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': '房地产广告',
    'version': '1.0',
    'summary': 'real estate',
    'sequence': 10,
    'description': """
    real estate
    """,
    'depends':[],
    'data': [
        'security/ir.model.access.csv',
        'views/estate_property_views.xml',
    ],
    'application': True,

}

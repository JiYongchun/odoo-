from odoo import models, fields, api
from lxml import etree
import xml.etree.ElementTree as ET

from odoo.exceptions import AccessError


class LeaveRequest(models.Model):
    print(111111111111111111111111111111111111111111111111111111)

    # @api.model
    # def get_user_group_name(self):
    #     print('打印信息')
    #     if self.env.user.has_group('leave_request.group_base'):
    #         return True
    #     else:
    #         return False

    _name = 'leave.request'
    _description = "请假申请与审批"

    name = fields.Char(string="请假人", required=True, readonly=True)



    days = fields.Integer(string="请假天数")
    start_date = fields.Date(string="开始日期")
    end_date = fields.Date(string="结束日期")
    reason = fields.Text(string="请假事由")
    result = fields.Selection([('Yes', '同意'), ('No', '不同意')],
                              string='审批意见')


    @api.model
    def get_user_group_name(self):
        print('打印信息')
        if self.env.user.has_group('leave_request.group_base'):
            return True
        else:
            return False
    print(123000000000000000000000000000000000000000)
    print("保护条")

    # @api.model
    # def zi_duan_quan_xian(self):
    #     if self.env.user.has_group('leave_request.group_base'):
    #         result_readonly_value=True
    #     return result_readonly_value


    result_readonly = fields.Boolean(compute='_compute_result_readonly')

    @api.depends('result')
    def _compute_result_readonly(self):
        for record in self:
            # 检查当前用户是否属于 leave_request.group_base 组
            record.result_readonly = self.env.user.has_group('leave_request.group_base')


    # @api.depends()
    # @api.model
    # def _compute_readonly(self):
    #     for record in self:
    #         record.compute_readonly = self.env.user.has_group('leave_request.group_base')
    #
    # print("保护条")
    # print(_compute_readonly)
    # print("保护条")


    last_seen = fields.Datetime("Last Seen", default=fields.Datetime.now)

    # @api.model
    # def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
    #     result = super(LeaveRequest, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar,
    #                                                   submenu=submenu)
    #
    #     if view_type == 'form':
    #         doc = etree.XML(result['arch'])
    #         for node in doc.xpath("//field[@name='result']"):
    #             # 检查当前用户是否属于 leave_request.group_base 组
    #             if self.env.user.has_group('leave_request.group_base'):
    #                 node.set('readonly', '1')
    #
    #         result['arch'] = etree.tostring(doc, encoding='unicode')
    #
    #     return result

    print(10000000000000000000000000000000000000000000000000000000000000000000000000000)




    print(11000000000000000000000000000000000000000000000000000000000000000)


    print(12000000000000000000000000000000000000000000000000000000000000000000000000000)


    # @api.model
    # def write_group(self, vals):
    #     if 'result' in vals and not self.env.user.has_group('leave_request.group_manager'):
    #         raise AccessError("只有请假审批权限用户组可以添加审批意见")
    #     return super(LeaveRequest, self).write(self, vals)




    # 默认用户名称
    @api.model
    def default_get(self, fields_list):
        # print(130000000000000000000000000000000000000000000000)
        # print(self.env.user.has_group('leave_request.group_base'))
        # print("保护条")
        defaults = super(LeaveRequest, self).default_get(fields_list)
        defaults['name'] = self.env.user.name
        # if self.env.user.has_group('leave_request.group_base'):
        #     print("当前用户属于指定用户组")
        #     group_value = True
        #     print(group_value)
        # else:
        #     print("当前用户不属于指定用户组")
        #     group_value = False
        #     print(group_value)
        return defaults





    # @api.model
    # def write(self, vals):
    #     if 'result' in vals and not self.env.user.has_group('leave_request.group_manager'):
    #         raise AccessError("只有请假审批权限用户组可以修改审批意见")
    #     return super(LeaveRequest, self).write(vals)

    # @api.model
    # def write(self, vals):
    #     record = self.browse(self.env.context.get('active_id'))
    #     if record:
    #         user_groups = self.env.user.groups_id
    #         is_manager_group = 'leave_request.group_manager' in user_groups.mapped('name')
    #         for field_name, value in vals.items():
    #             if is_manager_group and field_name != 'result':
    #                 raise AccessError("审批组只能修改审批意见字段")
    #             elif not is_manager_group and field_name == 'result':
    #                 raise AccessError("非审批组不能修改审批意见字段")
    #     return super(LeaveRequest, self).write(vals)

    # @api.model
    # def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
    #     res = super(LeaveRequest, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar,
    #                                                     submenu=submenu)
    #     if view_type == 'form':
    #         user_groups = self.env.user.groups_id
    #         if 'leave_request.group_manager' in user_groups.mapped('name'):
    #             doc = etree.XML(res['arch'])
    #             for field in doc.xpath("//field"):
    #                 field_name = field.get('name')
    #                 if field_name not in ['result']:
    #                     field.set('readonly', '1')
    #             res['arch'] = etree.tostring(doc)
    #     return res












